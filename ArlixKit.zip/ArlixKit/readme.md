# Arlix Pocket AI
##  Credits
creation data : 5 march 2025

created in : India

created by : Aarav Singh Latwal at age of 12

## Guides
there are 3 version of ai in different languages

1. Python (Compiled to exe) - ArlixPocketAI.exe
2. Python - APai.py (Source code of ArlixPocketAI.exe)
3. JavaScript - ArlixPocketAI.html (HTML/CSS + JS)

data are stored in aiData.json (Python)

## Arlix Pocket AI features
* Chatbot
* Dynamic
* Non-ruled based
* Fast
* Masterpeice
* Revolutionary 
* Open-source
* More Powerful then modern ai (if have full knowldage )
* No NLP included
* Self-learning
* Learn dynamicly by chatting

note: it don't have

```if it is in your computer, so it yours!```

It don't have a NLP so you need to talk to his language

learn my ai's language - learn.md   

```
 USA - Chatgpt
 China - Deepseek
 India - Arlix Pocket AI
 ```